<?
global $MESS;
$MESS["SALE_CHR_REC_ORDER"] = "Order ID not found.";
$MESS["SALE_CHR_REC_SUMM"] = "Wrong data. Sums not equal.";
$MESS["SALE_CHR_REC_TRANS"] = "Wrong data. Wrong transaction type.";
$MESS["SALE_CHR_REC_SIGN"] = "Wrong data. Signature not valid.";
$MESS["SALE_CHR_REC_PRODUCT"] = "Wrong data. Product not valid.";
?>