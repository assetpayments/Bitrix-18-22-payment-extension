<?
global $MESS;
$MESS["SALE_CHR_REC_ORDER"] = "ID Заказа неизвестен.";
$MESS["SALE_CHR_REC_SUMM"] = "Неверные данные. Суммы не совпадают.";
$MESS["SALE_CHR_REC_TRANS"] = "Неверные данные. Неверный тип транзакции.";
$MESS["SALE_CHR_REC_SIGN"] = "Неверные данные. Подпись не совпадает.";
$MESS["SALE_CHR_REC_PRODUCT"] = "Неверные данные. Продукт неверен.";
?>