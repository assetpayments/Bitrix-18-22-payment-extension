<?
global $MESS;
$MESS["ASSETPAYMENTS_MERCHANT"] = "Merchant ID";
$MESS["ASSETPAYMENTS_SECRET_KEY"] = "Secret key";
$MESS["ASSETPAYMENTS_PRICE_CURRENCY"] = "Currency";
$MESS["ASSETPAYMENTS_DESC_PRICE_CURRENCY"] = "Order currency ISO-3";
$MESS["ASSETPAYMENTS_RESPONSE_URL"] = "Return URL.";
$MESS["ASSETPAYMENTS_DESC_RESPONSE_URL"] = "Example http://{yourdomain}/personal/order/";
$MESS["ASSETPAYMENTS_SERVER_CALLBACK_URL"] = "Callback URL.";
$MESS["ASSETPAYMENTS_DESC_SERVER_CALLBACK_URL"] = "Example http://{yourdomain}/tools/asset_result.php";
$MESS["ASSETPAYMENTS_TEMPLATE_ID"] = "Template ID";
$MESS["ASSETPAYMENTS_DESC_TEMPLATE_ID"] = "Default = 19";

?>