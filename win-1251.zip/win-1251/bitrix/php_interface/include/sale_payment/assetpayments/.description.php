<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?><?
include(GetLangFileName(dirname(__FILE__) . "/", "/.description.php"));


$psTitle = "AssetPayments";
$psDescription = "<a href=\"https://assetpayments.com\" target=\"_blank\">https://assetpayments.com</a>";

$array = array(
    'assetpayments_merchant',
    'assetpayments_secret_key',
    'assetpayments_price_currency',
    'assetpayments_server_callback_url',
    'assetpayments_response_url',
    'assetpayments_language'
);


$arPSCorrespondence = array(
    "ASSET_MERCHANT" => array(
        "NAME" => GetMessage("ASSETPAYMENTS_MERCHANT"),
        "DESCR" => GetMessage("ASSETPAYMENTS_MERCHANT"),
        "VALUE" => "",
        "TYPE" => ""
    ),
    "ASSET_SECRET_KEY" => array(
        "NAME" => GetMessage("ASSETPAYMENTS_SECRET_KEY"),
        "DESCR" => GetMessage("ASSETPAYMENTS_SECRET_KEY"),
        "VALUE" => "",
        "TYPE" => ""
    ),
    //"ASSET_PRICE_CURRENCY" => array(
    //    "NAME" => GetMessage("ASSETPAYMENTS_PRICE_CURRENCY"),
    //    "DESCR" => GetMessage("ASSETPAYMENTS_DESC_PRICE_CURRENCY"),
    //    "VALUE" => "CURRENCY",
    //    "TYPE" => "ORDER"
    //),
    //"ASSET_SERVER_CALLBACK_URL" => array(
    //    "NAME" => GetMessage("ASSETPAYMENTS_SERVER_CALLBACK_URL"),
    //    "DESCR" => GetMessage("ASSETPAYMENTS_DESC_SERVER_CALLBACK_URL"),
    //    "VALUE" => "",
    //    "TYPE" => ""
    //),
    //"ASSET_RESPONSE_URL" => array(
    //    "NAME" => GetMessage("ASSETPAYMENTS_RESPONSE_URL"),
    //    "DESCR" => GetMessage("ASSETPAYMENTS_DESC_RESPONSE_URL"),
    //    "VALUE" => "",
    //    "TYPE" => ""
    //),
    "ASSET_TEMPLATE_ID" => array(
        "NAME" => GetMessage("ASSETPAYMENTS_TEMPLATE_ID"),
        "DESCR" => GetMessage("ASSETPAYMENTS_DESC_TEMPLATE_ID"),
        "VALUE" => "19",
        "TYPE" => ""
    ),
);
?>